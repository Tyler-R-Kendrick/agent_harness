import { loadConfig } from './config.ts';
import { LocalInferenceController } from './local-inference.ts';
import { SignalingClient } from './signaling-client.ts';
import { WebRTCInferenceDaemon } from './webrtc-client.ts';
import { WebSocketInferenceDaemon } from './websocket-fallback.ts';

const MAX_RECONNECT_DELAY_MS = 30_000;

export async function runService(): Promise<void> {
  let reconnectDelay = 1_000;
  let currentDaemon: { close(): void } | undefined;

  const shutdown = () => {
    console.log('Stopping Agent Harness Local Inference Daemon.');
    currentDaemon?.close();
    Deno.exit(0);
  };
  Deno.addSignalListener('SIGINT', shutdown);
  Deno.addSignalListener('SIGTERM', shutdown);

  while (true) {
    const config = loadConfig();
    const inference = new LocalInferenceController(config.localInferenceBaseUrl);

    try {
      console.log(`Starting Agent Harness Local Inference Daemon as ${config.peerId}.`);
      if (config.preferWebSocketFallback) {
        const daemon = new WebSocketInferenceDaemon(config, inference);
        currentDaemon = daemon;
        await daemon.connect();
      } else {
        const signaling = new SignalingClient(config.signalingUrl, config.peerId);
        const daemon = new WebRTCInferenceDaemon(config, signaling, inference);
        currentDaemon = daemon;
        await daemon.start();
      }
      reconnectDelay = 1_000;
      // Keep the daemon process alive until a signal or connection failure stops it.
      await new Promise(() => {});
    } catch (error) {
      console.error('Local inference daemon connection failed:', error);
      currentDaemon?.close();
      await new Promise((resolve) => setTimeout(resolve, reconnectDelay));
      reconnectDelay = Math.min(reconnectDelay * 2, MAX_RECONNECT_DELAY_MS);
    }
  }
}

if (import.meta.main) {
  await runService();
}
